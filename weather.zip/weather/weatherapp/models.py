from django.db import models

# Create your models here.
class City(models.Model):
    name=models.CharField(max_length=25)

    def __str__(self):
        return self.name
        return self.id

    class Meta:
        verbose_name_plural ='cities'

class contactdetails(models.Model):
    name=models.CharField(max_length=100)
    address = models.CharField(max_length=200)
    contactno=models.CharField(max_length=200)
    description = models.CharField(max_length=5000)

    def __str__(self):
        return self.name
