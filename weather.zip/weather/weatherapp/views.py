
from django.shortcuts import render,redirect
from django.http import  HttpResponseRedirect
import requests
from .models import City
from .forms import CityForm
from .forms import contactform
# Create your views here.
def index(request):
    url='http://api.openweathermap.org/data/2.5/weather?q={}&units=imperial&appid=a092aa010e4a3e3864564b351904fbd7'

    if request.method =='POST':
        form=CityForm(request.POST)
        form.save()
    form = CityForm()


    cities=City.objects.order_by('id').reverse()


    weatherdata=[]

    for city in cities:
        r = requests.get(url.format(city)).json()
        cityweather={
            'cityid':city.id,
            'city':city,
            'temperature':r['main']['temp'],
            'description':r['weather'][0]['description'],
            'icon':r['weather'][0]['icon']
    }
        weatherdata.append(cityweather)
    context={'weatherdata':weatherdata,'form':form}
    return render(request, 'weatherapp/weather.html',context)
def delete(request,id):
    City.objects.filter(pk=id).delete()

    return redirect('index1')
def contact(request):
    if(request.method=='POST'):
        form =contactform(request.POST)
        form.save()
        return HttpResponseRedirect('thanks')
    form = contactform()
    context={'form': form}
    return render(request,'weatherapp/contact.html', context)
def Thanks(request):
    return render(request,'weatherapp/Thanks.html')


