
from django.urls import path
from . import  views

urlpatterns = [

    path('', views.index,name='index1'),
    path('delete/<id>' ,views.delete, name='delete'),
    path('contact',views.contact,name='contact'),
    path('thanks',views.Thanks,name='thanks')
]