from django.forms import ModelForm, TextInput
from django import forms
from .models import City
from .models import contactdetails
class CityForm(ModelForm):
        class Meta:
            model=City
            fields=['name']
            widgets={'name':TextInput(attrs={'class':'input','placeholder':'CityName'})}
class contactform(forms.ModelForm):
    class Meta:
        model =contactdetails
        fields =['name', 'address', 'contactno', 'description']
        widgets = {'name': TextInput(attrs={'class': 'form-control', 'placeholder': 'Name'}),'address':TextInput(attrs={'class':'form-control','placeholder':'Address'}),'contactno':TextInput(attrs={'class':'form-control','placeholder':'Contact'}),'description':TextInput(attrs={'class':'form-control','placeholder':'Your Ideas'})}
